A brief documentation about VyOS can be found at
https://github.com/vyos-documentation or rendered at https://vyos.readthedocs.org

Another landing spot would be the old Wiki at http://wiki.vyos.net.

Build instructions for a 1U DIY VyOS bare metal router is [here](1u-diy-atom-c3000/README.md)
